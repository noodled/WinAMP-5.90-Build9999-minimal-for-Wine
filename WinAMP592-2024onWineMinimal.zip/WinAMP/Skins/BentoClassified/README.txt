********************************
Bento Classified skin for Winamp
(Released October 20, 2007.)
********************************

Based on the default skin
(the Bento Single-User-Interface) for
Winamp 5.5, but transformed into a (non-SUI)
classic skin just because I felt like it.
Inspired in part by Winamp3 Classified
(http://www.winamp.com/skins/details/142442)
and Winamp5 Classified
(http://www.winamp.com/skins/details/143266). 

-LuigiHann.

Copyright � 2007 LuigiHann. All rights reserved.